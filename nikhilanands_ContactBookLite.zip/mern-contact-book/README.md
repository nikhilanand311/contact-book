# MERN Contact Book Lite

A simple Contact Book application built using MongoDB, Express, React, and Node.js.

## Project Structure

```
mern-contact-book/
├── backend/    # Node.js + Express + MongoDB
└── frontend/   # React.js (Vite)
```

## Setup Instructions

### Prerequisites
- Node.js installed
- MongoDB installed and running locally on port 27017 (or update `.env`)

### 1. Backend Setup

Navigate to the `backend` folder and start the server:

```bash
cd backend
npm install
npm start
```

The server will start on `http://localhost:5000`.

### 2. Frontend Setup

Open a new terminal, navigate to the `frontend` folder, and start the React app:

```bash
cd frontend
npm install
npm run dev
```

The frontend will start on `http://localhost:5173` (or similar).

## Features

- **Add Contact**: Name, Phone, Email.
- **View Contacts**: List of all contacts.
- **Delete Contact**: Remove a contact.
