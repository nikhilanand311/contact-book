import { useState, useEffect } from 'react';
import axios from 'axios';
import ContactForm from './components/ContactForm';
import ContactList from './components/ContactList';

function App() {
  const [contacts, setContacts] = useState([]);
  const API_URL = 'http://localhost:5000/api/contacts';

  useEffect(() => {
    const fetchContacts = async () => {
      try {
        const response = await axios.get(API_URL);
        setContacts(response.data);
      } catch (error) {
        console.error('Error fetching contacts:', error);
      }
    };

    fetchContacts();
  }, []);

  const addContact = async (contact) => {
    try {
      const response = await axios.post(API_URL, contact);
      setContacts([response.data, ...contacts]);
    } catch (error) {
      console.error('Error adding contact:', error);
    }
  };

  const deleteContact = async (id) => {
    try {
      await axios.delete(`${API_URL}/${id}`);
      setContacts(contacts.filter(contact => contact._id !== id));
    } catch (error) {
      console.error('Error deleting contact:', error);
    }
  };

  return (
    <div className="app-container">
      <header>
        <h1>Contact Book Lite</h1>
      </header>
      <main>
        <ContactForm onAdd={addContact} />
        <ContactList contacts={contacts} onDelete={deleteContact} />
      </main>
    </div>
  );
}

export default App;